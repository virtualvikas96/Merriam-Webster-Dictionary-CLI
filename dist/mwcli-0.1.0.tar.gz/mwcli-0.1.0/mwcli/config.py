from dotenv import load_dotenv
import os

load_dotenv()
MW_API_KEY = os.getenv("MW_API_KEY")

